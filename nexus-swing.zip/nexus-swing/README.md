# NEXUS SWING TRADER — Deploy Guide

## Struktur Project

```
nexus-swing/
├── api/
│   └── groq.js          ← Backend proxy (API key aman di server)
├── public/
│   └── index.html       ← Frontend (tanpa API key)
├── vercel.json          ← Routing config
├── package.json
└── README.md
```

## Deploy ke Vercel (Gratis)

### Step 1 — Siapkan Groq API Key
1. Buka https://console.groq.com/keys
2. Login / daftar (gratis)
3. Klik **Create API Key**
4. Copy key (format: `gsk_…`)

### Step 2 — Upload ke GitHub
1. Buat repo baru di https://github.com/new
2. Upload seluruh folder `nexus-swing/` ke repo tersebut
3. Commit & push

### Step 3 — Deploy di Vercel
1. Buka https://vercel.com → **Add New Project**
2. Import repo GitHub yang baru dibuat
3. Klik **Environment Variables** → tambahkan:
   - **Name:** `GROQ_API_KEY`
   - **Value:** `gsk_…` (key dari Step 1)
4. Klik **Deploy**

### Step 4 — Selesai!
Aplikasi live di URL Vercel kamu.
Pengguna **tidak perlu tahu** Groq API key — tersimpan aman di server.

---

## Cara Kerja Backend

```
Browser → POST /api/groq → Vercel Function → Groq API
                              (key aman di env)
```

File `api/groq.js` adalah serverless function yang:
- Menerima request dari frontend
- Menambahkan `Authorization: Bearer ${GROQ_API_KEY}` dari env variable
- Meneruskan ke Groq API
- Mengembalikan response ke frontend

**API key TIDAK pernah dikirim ke browser.**

---

## Environment Variables

| Nama | Nilai | Keterangan |
|------|-------|-----------|
| `GROQ_API_KEY` | `gsk_…` | **Wajib** — dari console.groq.com |

---

## Local Development (Opsional)

```bash
npm install -g vercel
cd nexus-swing
vercel dev
# Buka http://localhost:3000
```

Buat file `.env.local`:
```
GROQ_API_KEY=gsk_xxxxxxxxxxxxx
```
